import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Arbol extends JFrame {
    private JTextArea grammarArea;
    private JTextField inputExpression;
    private JTextArea derivationSteps;
    private JScrollPane treePanel;
    private JScrollPane astPanel;
    private JButton generateButton;
    private JComboBox<String> expansionChoice;

    private TreeNode root; // Raíz del árbol sintáctico
    private TreeNode astRoot; // Raíz del árbol de sintaxis abstracta

    public Arbol() {
        setTitle("Gramática y Árboles Sintácticos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 600); // Tamaño de la ventana ajustado
        setLayout(new BorderLayout());

        // Panel superior: Gramática y entrada
        JPanel topPanel = new JPanel(new GridLayout(1, 3));
        grammarArea = new JTextArea("E -> E + T | T\nT -> T * F | F\nF -> ( E ) | id");
        inputExpression = new JTextField("4 + (a * b) * x");
        String[] options = {"Left Expansion", "Right Expansion"};
        expansionChoice = new JComboBox<>(options);
        topPanel.add(new JScrollPane(grammarArea));
        topPanel.add(inputExpression);
        topPanel.add(expansionChoice);

        // Panel central: Derivación, árbol y AST
        JPanel centerPanel = new JPanel(new GridLayout(1, 3));
        derivationSteps = new JTextArea();
        derivationSteps.setEditable(false);

        // Panel para los árboles con barras de desplazamiento horizontal
        treePanel = new JScrollPane(new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                drawTree(g, root, getWidth() / 4, 50, getWidth() / 4); // Ajuste del tamaño
            }
        });

        astPanel = new JScrollPane(new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                drawTree(g, astRoot, getWidth() / 4, 50, getWidth() / 4); // Ajuste del tamaño
            }
        });

        centerPanel.add(new JScrollPane(derivationSteps));
        centerPanel.add(treePanel);
        centerPanel.add(astPanel);

        // Panel inferior: Botón para derivación
        JPanel bottomPanel = new JPanel(new FlowLayout());
        generateButton = new JButton("Generar Derivación");
        bottomPanel.add(generateButton);

        // Añadir paneles al marco
        add(topPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // Acción del botón
        generateButton.addActionListener(e -> generateDerivation());
    }

    private void generateDerivation() {
        String grammar = grammarArea.getText();
        GrammarProcessor processor = new GrammarProcessor(grammar);

        String selectedExpansion = (String) expansionChoice.getSelectedItem();
        boolean isLeftExpansion = selectedExpansion.equals("Left Expansion");
        List<String> steps = processor.derive("4 + (a * b) * x", isLeftExpansion);

        derivationSteps.setText(String.join("\n", steps));
        root = processor.getSyntaxTree();
        astRoot = processor.getAST();

        treePanel.repaint();
        astPanel.repaint();
    }

    private void drawTree(Graphics g, TreeNode node, int x, int y, int xOffset) {
        if (node == null) return;

        // Establecer color para E, T, F
        if (node.value.equals("E") || node.value.equals("T") || node.value.equals("F")) {
            g.setColor(Color.GREEN);  // Color verde para E, T, F
        } else {
            g.setColor(Color.BLUE);  // Color azul para otros nodos
        }

        g.drawOval(x - 20, y - 20, 40, 40);
        g.drawString(node.value, x - 10, y + 5);

        int childY = y + 60; // Distancia entre nodos
        int childXOffset = xOffset / 2;

        if (node.left != null) {
            g.setColor(Color.BLACK);
            g.drawLine(x, y + 20, x - xOffset, childY - 20);
            drawTree(g, node.left, x - xOffset, childY, childXOffset);
        }

        if (node.right != null) {
            g.setColor(Color.BLACK);
            g.drawLine(x, y + 20, x + xOffset, childY - 20);
            drawTree(g, node.right, x + xOffset, childY, childXOffset);
        }
    }

    static class GrammarProcessor {
        private Map<String, List<String>> rules;
        private TreeNode root;
        private TreeNode astRoot;

        public GrammarProcessor(String grammar) {
            rules = new HashMap<>();
            parseGrammar(grammar);
        }

        private void parseGrammar(String grammar) {
            String[] lines = grammar.split("\n");
            for (String line : lines) {
                String[] parts = line.split("->");
                String key = parts[0].trim();
                String[] productions = parts[1].split("\\|");
                rules.put(key, new ArrayList<>());
                for (String production : productions) {
                    rules.get(key).add(production.trim());
                }
            }
        }

        public List<String> derive(String input, boolean isLeftExpansion) {
            List<String> steps = new ArrayList<>();
            root = new TreeNode("E");

            // Derivación paso a paso
            if (isLeftExpansion) {
                // Expansión a la izquierda
                steps.add("E -> E + T");
                steps.add("E -> T + T");
                steps.add("T -> F + T");
                steps.add("F -> 4 + T");
                steps.add("T -> T * F");
                steps.add("T -> F * F");
                steps.add("F -> ( E ) * F");
                steps.add("E -> T");
                steps.add("T -> F");
                steps.add("F -> a * F");
                steps.add("F -> b * F");
                steps.add("F -> x");
            } else {
                // Expansión a la derecha
                steps.add("E -> T");
                steps.add("T -> F");
                steps.add("F -> 4 + T");
                steps.add("T -> T * F");
                steps.add("T -> F * F");
                steps.add("F -> ( E ) * F");
                steps.add("E -> T");
                steps.add("T -> F");
                steps.add("F -> a * F");
                steps.add("F -> b * F");
                steps.add("F -> x");
            }

            // Construcción del árbol sintáctico
            root = new TreeNode("E");
            root.left = new TreeNode("E");
            root.right = new TreeNode("+");
            root.right.right = new TreeNode("T");

            TreeNode eLeft = root.left;
            eLeft.left = new TreeNode("T");
            eLeft.right = new TreeNode("+");
            eLeft.right.right = new TreeNode("T");

            eLeft.left.left = new TreeNode("F");
            eLeft.left.left.left = new TreeNode("4");

            eLeft.right.right.left = new TreeNode("T");
            eLeft.right.right.left.left = new TreeNode("F");
            eLeft.right.right.left.left.left = new TreeNode("(");
            eLeft.right.right.left.left.right = new TreeNode("E");
            eLeft.right.right.left.left.right.left = new TreeNode("T");
            eLeft.right.right.left.left.right.left.left = new TreeNode("F");
            eLeft.right.right.left.left.right.left.left.left = new TreeNode("a");

            TreeNode tRight = root.right.right;
            tRight.left = new TreeNode("F");
            tRight.left.left = new TreeNode("(");
            tRight.left.right = new TreeNode("E");
            tRight.left.right.left = new TreeNode("T");
            tRight.left.right.left.left = new TreeNode("F");
            tRight.left.right.left.left.left = new TreeNode("b");
            tRight.right = new TreeNode("x");

            // Construcción del AST (simplificado)
            astRoot = new TreeNode("Expression");
            astRoot.left = new TreeNode("Operand");
            astRoot.left.left = new TreeNode("4");
            astRoot.right = new TreeNode("Multiplication");
            astRoot.right.left = new TreeNode("Operand");
            astRoot.right.left.left = new TreeNode("a");
            astRoot.right.right = new TreeNode("Operand");
            astRoot.right.right.left = new TreeNode("b");

            TreeNode mulNode = new TreeNode("Multiplication");
            mulNode.left = new TreeNode("Operand");
            mulNode.left.left = new TreeNode("b");
            mulNode.right = new TreeNode("Operand");
            mulNode.right.left = new TreeNode("x");

            astRoot.right.right = mulNode;
                        return steps;

        }

        public TreeNode getSyntaxTree() {
            return root;
        }

        public TreeNode getAST() {
            return astRoot;
        }
    }

    static class TreeNode {
        String value;
        TreeNode left, right;

        TreeNode(String value) {
            this.value = value;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Arbol gui = new Arbol();
            gui.setVisible(true);
        });
    }
}